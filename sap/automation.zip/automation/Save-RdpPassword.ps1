<#
.SYNOPSIS
    一次性运行：把远程 PC 的密码用 DPAPI 加密保存到 rdp-cred.xml。

    DPAPI 加密绑定【当前 Windows 用户账户】，只有同一用户在本机能解密，
    比把明文密码写进脚本安全得多。计划任务必须以同一个用户身份运行。

.PARAMETER UserName
    远程登录用户名（凭据窗口里已预填的那个，默认 "ou"）。

.EXAMPLE
    .\Save-RdpPassword.ps1
    .\Save-RdpPassword.ps1 -UserName ou
#>
[CmdletBinding()]
param(
    [string]$UserName = 'ou',
    [string]$CredFile = "$PSScriptRoot\rdp-cred.xml"
)

$secure = Read-Host "请输入远程 PC ($UserName) 的密码" -AsSecureString
$cred   = New-Object System.Management.Automation.PSCredential($UserName, $secure)
$cred | Export-Clixml -LiteralPath $CredFile

Write-Host "密码已加密保存到: $CredFile" -ForegroundColor Green
Write-Host "（只有当前用户 $env:USERNAME 在本机能解密。）"
