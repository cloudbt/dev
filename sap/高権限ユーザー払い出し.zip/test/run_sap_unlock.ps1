﻿# SAP 用户解锁和密码重置脚本
# 调用 VBS 脚本来执行 SAP 操作
# 用法: .\run_sap_unlock.ps1 -UserID "用户名" -PW "密码"
# 或者不带参数运行，将会提示输入

param(
    [string]$UserID,
    [string]$PW
)

# 获取当前脚本所在目录
$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$vbsScriptPath = Join-Path $scriptPath "Unlock1111 copy.vbs"

# 检查 VBS 脚本是否存在
if (-not (Test-Path $vbsScriptPath)) {
    Write-Host "错误: 找不到 VBS 脚本文件: $vbsScriptPath" -ForegroundColor Red
    exit 1
}

# 如果没有提供UserID参数，提示用户输入
if ([string]::IsNullOrWhiteSpace($UserID)) {
    $defaultUserID = "1DKI99"
    $UserID = Read-Host "请输入用户名ID (默认: $defaultUserID)"

    # 如果用户直接按回车，使用默认值
    if ([string]::IsNullOrWhiteSpace($UserID)) {
        $UserID = $defaultUserID
    }
}

# 如果没有提供PW参数，生成默认密码
if ([string]::IsNullOrWhiteSpace($PW)) {
    # 获取当前日期的月日 (mmdd 格式)
    $mmdd = Get-Date -Format "MMdd"
    # 生成密码: TEST + mmdd + test
    $PW = "TEST" + $mmdd + "test"
}

# 显示信息
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "SAP 用户解锁和密码重置" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "用户名ID: $UserID" -ForegroundColor Green
Write-Host "密码: $PW" -ForegroundColor Green
Write-Host "========================================`n" -ForegroundColor Cyan

# 如果是交互模式（未提供参数），需要确认执行
if ($PSBoundParameters.Count -eq 0) {
    $confirm = Read-Host "是否继续执行? (Y/N)"
    if ($confirm -ne "Y" -and $confirm -ne "y") {
        Write-Host "操作已取消。" -ForegroundColor Yellow
        exit 0
    }
}

# 调用 VBS 脚本
Write-Host "`n正在调用 SAP 脚本..." -ForegroundColor Yellow

try {
    # 使用 cscript 执行 VBS 脚本，传递用户名和密码参数
    $result = & cscript.exe //NoLogo $vbsScriptPath $UserID $PW 2>&1

    # 显示执行结果
    Write-Host "`n执行结果:" -ForegroundColor Cyan
    Write-Host $result -ForegroundColor White

    if ($LASTEXITCODE -eq 0) {
        Write-Host "`n操作成功完成!" -ForegroundColor Green
    } else {
        Write-Host "`n操作可能遇到问题，退出代码: $LASTEXITCODE" -ForegroundColor Yellow
    }
} catch {
    Write-Host "`n错误: $_" -ForegroundColor Red
    exit 1
}

# 如果是交互模式，等待用户按键后退出
if ($PSBoundParameters.Count -eq 0) {
    Write-Host "`n按任意键退出..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}
