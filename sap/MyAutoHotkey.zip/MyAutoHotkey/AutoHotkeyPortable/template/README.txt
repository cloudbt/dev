此目录保存 Operation Toolkit 使用的无客户信息通用模板。

支持的占位符：
WorkMemo.txt: {INCIDENT}, {START_TIME}
InvestigationMemo.txt: {INCIDENT}, {SYSTEM}, {ENVIRONMENT}, {CREATED_AT}

可以调整文字和栏目，但请保留仍需自动替换的占位符。
