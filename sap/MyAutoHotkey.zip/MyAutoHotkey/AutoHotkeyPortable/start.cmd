@echo off
setlocal
cd /d "%~dp0"

if not exist "%~dp0AutoHotkey64.exe" (
    echo AutoHotkey64.exe was not found in: %~dp0
    pause
    exit /b 1
)

if not exist "%~dp0script\main.ahk" (
    echo script\main.ahk was not found in: %~dp0
    pause
    exit /b 1
)

start "" "%~dp0AutoHotkey64.exe" "%~dp0script\main.ahk"
endlocal
