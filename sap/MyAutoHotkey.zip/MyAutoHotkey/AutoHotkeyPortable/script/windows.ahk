OpenEventViewer(*) {
    RunSystemTool("eventvwr.msc", "Event Viewer")
}

OpenServicesConsole(*) {
    RunSystemTool("services.msc", "Services")
}

OpenComputerManagement(*) {
    RunSystemTool("compmgmt.msc", "Computer Management")
}

CopyWindowsInvestigationChecklist(*) {
    text := "Windows Server / AWS Investigation Checklist`r`n"
        . "===========================================`r`n"
        . "[ ] Service status (read-only check)：`r`n"
        . "[ ] Event Log：`r`n[ ] Disk：`r`n[ ] CPU：`r`n[ ] Memory：`r`n"
        . "[ ] Certificate：`r`n[ ] Log Update Time：`r`n"
        . "[ ] Impact：`r`n[ ] Evidence：`r`n[ ] Next Action：`r`n`r`n"
        . "WARNING: 本工具不会重启 Service、Server，也不会修改 AWS 配置。"
    CopyToClipboard(text, "Windows 调查 Checklist 已复制。")
}
