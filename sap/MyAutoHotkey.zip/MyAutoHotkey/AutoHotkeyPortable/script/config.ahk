; Safe example configuration. Change these paths for your environment.
global APP_ROOT := A_ScriptDir "\.."
global SCRIPT_ROOT := A_ScriptDir
global TEMPLATE_ROOT := APP_ROOT "\template"
global LOG_ROOT := APP_ROOT "\logs"
global TRAY_MENU_ENABLED := false

global WORK_ROOT := "C:\Users\whz\Documents\MailTask\"
global INCIDENT_LIST := "C:\Users\whz\Documents\MailTask\AsiOse_Incident_List.xlsx"
global PERSONAL_TASK_LIST := "C:\Users\whz\Documents\MailTask\PersonalTaskList_Wang.xlsx"
global RUNBOOK_ROOT := WORK_ROOT "\Runbook"
global EVIDENCE_ROOT := WORK_ROOT "\02_Evidence"
global WORKING_ROOT := WORK_ROOT "\Working"
global PERSONAL_MEMO := "C:\Users\whz\Desktop\memo.txt"

global SAP_LOGON := "C:\Program Files\SAP\FrontEnd\SAPgui\saplogon.exe"
global SAP_LOGON_EXE := "saplogon.exe"

global EDGE_PATH := "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
global CHROME_PATH := "C:\Program Files\Google\Chrome\Application\chrome.exe"

global SHAREPOINT_INVOICE_URL := "https://aventechconsulting.sharepoint.com/sites/Subcontractor/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FSubcontractor%2FShared%20Documents%2FGeneral%2F10%5F%E5%90%84%E7%A8%AE%E6%89%8B%E7%B6%9A%E3%81%8D%E3%83%BB%E6%8F%90%E5%87%BA%E6%9B%B8%E9%A1%9E%2F01%5F%E4%BC%9A%E7%A4%BE%2FCBT%E6%A0%AA%E5%BC%8F%E4%BC%9A%E7%A4%BE%2F%E8%AB%8B%E6%B1%82%E6%9B%B8&viewid=0798fb3c%2D76c0%2D457b%2D8215%2D4fde8ea2a89f&p=true&ga=1"
global CLAUDE_USAGE_URL := "https://claude.ai/settings/usage"
global CLAUDE_CHROME_PROFILE := "Profile 3"
global CODEX_USAGE_URL := "https://chatgpt.com/codex/cloud/settings/analytics#usage"
global CHATGPT_URL := "https://chatgpt.com"
global CHATGPT_CHROME_PROFILE := "Profile 5"

global WATCH_FILES_ROOT := "C:\work\work-git\git\auto\automation\WatchFilesAndRunScripts"
global WATCH_FILES_SCRIPT := WATCH_FILES_ROOT "\Watch-FilesAndRunScripts.ps1"
