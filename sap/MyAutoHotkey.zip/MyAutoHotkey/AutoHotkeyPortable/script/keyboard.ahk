::ots::お疲れ様です。
::yor::よろしくお願いいたします。
::ose::お世話になっております。

^!n::OpenPersonalMemo()
^!+r::Reload()
^!c::CopyCurrentTimestamp()

OpenPersonalMemo(*) {
    if !EnsureDirectory(WORKING_ROOT)
        return
    if !FileExist(PERSONAL_MEMO)
        WriteTextFile(PERSONAL_MEMO, "Personal Memo`r`n=============`r`n`r`n")
    OpenInNotepad(PERSONAL_MEMO)
}

CopyCurrentTimestamp(*) {
    CopyToClipboard(Timestamp(), "当前时间已复制。")
}
