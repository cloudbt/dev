OpenOrActivate(exeName, path, *) {
    if WinExist("ahk_exe " exeName) {
        WinActivate
        return true
    }

    if !FileExist(path) {
        ShowError("程序不存在：`n" path "`n`n请修改 script\config.ahk。")
        return false
    }

    try {
        Run(path)
        return true
    } catch as err {
        ShowError("无法启动程序：`n" path "`n`n" err.Message)
        return false
    }
}

SafeOpen(path, *) {
    if !FileExist(path) && !DirExist(path) {
        ShowError("路径不存在：`n" path "`n`n请修改 script\config.ahk。")
        return false
    }

    try {
        Run(path)
        return true
    } catch as err {
        ShowError("无法打开：`n" path "`n`n" err.Message)
        return false
    }
}

CopyToClipboard(text, message := "已复制到剪贴板。") {
    A_Clipboard := text
    if message != ""
        TrayTip(message, "Operation Toolkit", 1)
    return text
}

EnsureDirectory(path) {
    if DirExist(path)
        return true
    try {
        DirCreate(path)
        return true
    } catch as err {
        ShowError("无法创建目录：`n" path "`n`n" err.Message)
        return false
    }
}

SanitizeFileName(value) {
    value := Trim(value)
    value := RegExReplace(value, "[<>:`"/\\|?*\x00-\x1F]", "_")
    value := Trim(value, " .`t`r`n")
    if value = ""
        value := "Untitled"
    if RegExMatch(value, "i)^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$")
        value .= "_"
    return value
}

Timestamp(format := "yyyy-MM-dd HH:mm:ss") {
    return FormatTime(, format)
}

GetMonthFolder(rootPath) {
    return rootPath "\" FormatTime(, "yyyy") "\" FormatTime(, "yyyyMM")
}

AskText(prompt, title := "Operation Toolkit", defaultValue := "") {
    result := InputBox(prompt, title, "w460 h150", defaultValue)
    return result.Result = "OK" ? Trim(result.Value) : ""
}

ShowError(message) {
    MsgBox(message, "Operation Toolkit", "Icon!")
}

RunSystemTool(command, displayName) {
    try {
        Run(command)
        WriteActionLog(displayName " opened")
        return true
    } catch as err {
        ShowError("无法打开 " displayName "。`n`n" err.Message "`n`n可能是公司 PC 权限策略所致。")
        return false
    }
}

RunPowerShellScript(scriptPath, workingDirectory, displayName) {
    if !DirExist(workingDirectory) {
        ShowError("PowerShell 工作目录不存在：`n" workingDirectory "`n`n请修改 script\config.ahk。")
        return false
    }
    if !FileExist(scriptPath) {
        ShowError("PowerShell 脚本不存在：`n" scriptPath "`n`n请修改 script\config.ahk。")
        return false
    }

    command := BuildPowerShellScriptCommand(scriptPath)
    try {
        Run(command, workingDirectory)
        WriteActionLog(displayName " started")
        return true
    } catch as err {
        ShowError("无法启动 " displayName "。`n`n" err.Message)
        return false
    }
}

BuildPowerShellScriptCommand(scriptPath) {
    SplitPath(scriptPath, &scriptName)
    return 'powershell.exe -ExecutionPolicy Bypass -File ".\' scriptName '"'
}

OpenBrowserUrls(browserPath, browserName, urls, profileDirectory := "") {
    if FileExist(browserPath) {
        command := BuildBrowserCommand(browserPath, urls, profileDirectory)

        try {
            Run(command)
            WriteActionLog(browserName " link opened")
            return true
        } catch as err {
            ShowError("无法使用 " browserName " 打开链接。`n`n" err.Message)
            return false
        }
    }

    for url in urls {
        try Run(url)
        catch as err {
            ShowError(browserName " 不存在，默认浏览器也无法打开链接。`n`n" err.Message)
            return false
        }
    }
    TrayTip(browserName " 不存在，已改用默认浏览器。", "Operation Toolkit", 2)
    WriteActionLog("Default browser link opened")
    return true
}

BuildBrowserCommand(browserPath, urls, profileDirectory := "") {
    command := Format('"{1}"', browserPath)
    if profileDirectory != ""
        command .= Format(' --profile-directory="{1}"', profileDirectory)
    for url in urls
        command .= Format(' "{1}"', url)
    return command
}

ReadTemplate(fileName, fallback := "") {
    path := TEMPLATE_ROOT "\" fileName
    if !FileExist(path)
        return fallback
    try return FileRead(path, "UTF-8")
    catch as err {
        ShowError("无法读取模板：`n" path "`n`n" err.Message)
        return fallback
    }
}

WriteTextFile(path, content, overwrite := false) {
    if FileExist(path) && !overwrite
        return false
    try {
        if FileExist(path)
            FileDelete(path)
        FileAppend(content, path, "UTF-8")
        return true
    } catch as err {
        ShowError("无法写入文件：`n" path "`n`n" err.Message)
        return false
    }
}

OpenInNotepad(path) {
    try Run("notepad.exe `"" path "`"")
    catch as err
        ShowError("无法用 Notepad 打开文件：`n" path "`n`n" err.Message)
}

WriteActionLog(action) {
    if !EnsureDirectory(LOG_ROOT)
        return
    logPath := LOG_ROOT "\" FormatTime(, "yyyy-MM-dd") ".log"
    try FileAppend(Timestamp() " | " action "`n", logPath, "UTF-8")
}
