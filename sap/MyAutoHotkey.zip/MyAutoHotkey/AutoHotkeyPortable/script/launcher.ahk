^!t::OpenPersonalTaskList()
^!i::OpenIncidentList()
^!r::OpenRunbook()
^!e::OpenEvidenceRoot()
^!s::OpenSapLogon()
^!w::OpenWorkingFolder()
^!+w::StartFilesWatcher()

OpenPersonalTaskList(*) {
    SafeOpen(PERSONAL_TASK_LIST)
}

OpenIncidentList(*) {
    SafeOpen(INCIDENT_LIST)
}

OpenRunbook(*) {
    SafeOpen(RUNBOOK_ROOT)
}

OpenEvidenceRoot(*) {
    SafeOpen(EVIDENCE_ROOT)
}

OpenSapLogon(*) {
    OpenOrActivate(SAP_LOGON_EXE, SAP_LOGON)
}

OpenWorkingFolder(*) {
    SafeOpen(WORKING_ROOT)
}

StartFilesWatcher(*) {
    RunPowerShellScript(WATCH_FILES_SCRIPT, WATCH_FILES_ROOT, "Watch Files And Run Scripts")
}
