CopyJp1Precheck(*) {
    text := "JP1 作業前 Checklist`r`n"
        . "====================`r`n"
        . "[ ] 対象ジョブネット：`r`n[ ] 実行予定：`r`n[ ] 前後続関係：`r`n"
        . "[ ] カレンダー：`r`n[ ] スケジュール：`r`n"
        . "[ ] 変更前 screenshot：`r`n[ ] 変更後 screenshot：`r`n"
        . "[ ] 戻し方法：`r`n`r`n"
        . "WARNING: 本番 JP1 的操作必须人工确认。"
    CopyToClipboard(text, "JP1 作业前 Checklist 已复制。")
}

CopyJp1AbnormalEndChecklist(*) {
    text := "JP1 Job Abnormal End Investigation`r`n"
        . "==================================`r`n"
        . "発生時間：`r`nJobnet：`r`nJob：`r`nReturn Code：`r`nLog：`r`n"
        . "Previous Job：`r`nNext Job：`r`nRerun possibility：`r`n"
        . "Impact：`r`nNext Action：`r`n"
    CopyToClipboard(text, "JP1 异常结束调查模板已复制。")
}

CopyJp1ScheduleChangeChecklist(*) {
    text := "JP1 Schedule Change Checklist (manual operation only)`r`n"
        . "==================================================`r`n"
        . "[ ] Current schedule：`r`n[ ] New schedule：`r`n[ ] Calendar：`r`n"
        . "[ ] Dependency：`r`n[ ] Approval：`r`n[ ] Before evidence：`r`n"
        . "[ ] After evidence：`r`n[ ] Rollback：`r`n`r`n"
        . "WARNING: 本工具不会修改 JP1 定义或 Schedule。"
    CopyToClipboard(text, "JP1 Schedule Change Checklist 已复制。")
}
