CreateEvidenceFolder(*) {
    incident := AskText("Incident No（例：INC51031）を入力してください。", "Create Evidence Folder")
    if incident = ""
        return
    systemName := AskText("System（例：SAP）を入力してください。", "Create Evidence Folder")
    if systemName = ""
        return
    description := AskText("Description（例：ST22 Dump）を入力してください。", "Create Evidence Folder")
    if description = ""
        return

    incident := SanitizeFileName(incident)
    systemName := SanitizeFileName(systemName)
    description := SanitizeFileName(description)
    folderPath := GetMonthFolder(EVIDENCE_ROOT) "\" incident "_" systemName "_" description

    if !EnsureDirectory(folderPath)
        return
    CopyToClipboard(folderPath, "Evidence 路径已复制。")
    SafeOpen(folderPath)
    WriteActionLog("Evidence folder created")
}

CreateWorkMemo(*) {
    incident := AskText("Incident No を入力してください。", "Create Work Memo")
    if incident = ""
        return
    incident := SanitizeFileName(incident)

    if !EnsureDirectory(WORKING_ROOT)
        return
    memoPath := WORKING_ROOT "\" incident "_WorkMemo.txt"
    if FileExist(memoPath) {
        TrayTip("既存の Work Memo を開きます。", "Operation Toolkit", 1)
        OpenInNotepad(memoPath)
        return
    }

    fallback := "Incident：{INCIDENT}`r`nStart Time：{START_TIME}`r`n`r`n"
        . "System：`r`n`r`nEnvironment：`r`nDEV / QAS / PRD`r`n`r`n"
        . "Work Type：`r`n作業 / 障害 / 調査 / 問い合わせ`r`n`r`n"
        . "■ Current Status`r`n`r`n■ Investigation`r`n`r`n■ Action`r`n`r`n"
        . "■ Result`r`n`r`n■ Evidence`r`n`r`n■ Next Action`r`n`r`n■ Actual Hour`r`n"
    content := ReadTemplate("WorkMemo.txt", fallback)
    content := StrReplace(content, "{INCIDENT}", incident)
    content := StrReplace(content, "{START_TIME}", Timestamp())

    if WriteTextFile(memoPath, content) {
        OpenInNotepad(memoPath)
        WriteActionLog("Work memo created")
    }
}

CreateInvestigationMemo(*) {
    incident := AskText("Incident No を入力してください。", "Create Investigation Memo")
    if incident = ""
        return
    systemName := AskText("System を入力してください。", "Create Investigation Memo")
    if systemName = ""
        return
    environment := AskText("Environment（DEV / QAS / PRD）を入力してください。", "Create Investigation Memo")
    if environment = ""
        return

    incident := SanitizeFileName(incident)
    if !EnsureDirectory(WORKING_ROOT)
        return
    memoPath := WORKING_ROOT "\" incident "_InvestigationMemo.txt"
    if FileExist(memoPath) {
        TrayTip("既存の Investigation Memo を開きます。", "Operation Toolkit", 1)
        OpenInNotepad(memoPath)
        return
    }

    fallback := "Incident：{INCIDENT}`r`nSystem：{SYSTEM}`r`nEnvironment：{ENVIRONMENT}`r`n"
        . "Occurred Time：`r`nMemo Created：{CREATED_AT}`r`n`r`n"
        . "■ Symptom`r`n`r`n■ Impact`r`n`r`n■ Error`r`n`r`n"
        . "■ Investigation`r`n`r`n■ Finding`r`n`r`n■ Cause`r`n`r`n"
        . "■ Action`r`n`r`n■ Next Action`r`n"
    content := ReadTemplate("InvestigationMemo.txt", fallback)
    content := StrReplace(content, "{INCIDENT}", incident)
    content := StrReplace(content, "{SYSTEM}", systemName)
    content := StrReplace(content, "{ENVIRONMENT}", environment)
    content := StrReplace(content, "{CREATED_AT}", Timestamp())

    if WriteTextFile(memoPath, content) {
        OpenInNotepad(memoPath)
        WriteActionLog("Investigation memo created")
    }
}

CreateDailyMemo(*) {
    if !EnsureDirectory(WORKING_ROOT)
        return
    memoPath := WORKING_ROOT "\" FormatTime(, "yyyy-MM-dd") "_DailyMemo.txt"
    if FileExist(memoPath) {
        OpenInNotepad(memoPath)
        return
    }
    content := "Daily Memo - " FormatTime(, "yyyy-MM-dd") "`r`n========================`r`n`r`n"
        . "■ Today's Top 3`r`n1. `r`n2. `r`n3. `r`n`r`n"
        . "■ Waiting`r`n`r`n■ PROD Work`r`n`r`n■ Completed`r`n`r`n"
        . "■ Tomorrow First Action`r`n"
    if WriteTextFile(memoPath, content) {
        OpenInNotepad(memoPath)
        WriteActionLog("Daily memo created")
    }
}
