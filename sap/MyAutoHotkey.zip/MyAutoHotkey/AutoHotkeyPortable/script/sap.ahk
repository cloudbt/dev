CopySapProdSafetyChecklist(*) {
    text := "SAP PROD Safety Checklist`r`n"
        . "=========================`r`n"
        . "[ ] Incident：`r`n"
        . "[ ] Target System：`r`n"
        . "[ ] Approval：`r`n"
        . "[ ] Runbook：`r`n"
        . "[ ] Backout：`r`n"
        . "[ ] Before Screenshot：`r`n"
        . "[ ] Evidence Folder：`r`n"
        . "[ ] Maintenance Window：`r`n"
        . "[ ] Impact：`r`n"
        . "[ ] Post Check：`r`n`r`n"
        . "WARNING: PROD / F56 操作需要人工确认。本工具不会执行任何生产变更。"
    CopyToClipboard(text, "SAP PROD Safety Checklist 已复制。")
}

CopySapJobDumpChecklist(*) {
    text := "SAP Job / Dump Investigation Checklist`r`n"
        . "=======================================`r`n"
        . "対象環境：`r`n発生日時：`r`n対象User：`r`n対象Job：`r`n`r`n"
        . "[ ] SM37 - Job status / Job log / Spool`r`n"
        . "[ ] ST22 - Runtime Error / User / Time`r`n"
        . "[ ] SM21 - System Log`r`n"
        . "[ ] SM50 / SM66 - Work Process`r`n"
        . "[ ] SM13 - Update Record`r`n`r`n"
        . "確認結果：`r`n原因候補：`r`nNext Action：`r`n"
    CopyToClipboard(text, "SAP Job / Dump 调查 Checklist 已复制。")
}

CopySapTransportChecklist(*) {
    text := "SAP Transport Checklist (manual operation only)`r`n"
        . "===============================================`r`n"
        . "[ ] Source：`r`n[ ] Target：`r`n[ ] Transport Request：`r`n"
        . "[ ] Approval：`r`n[ ] Import Order：`r`n[ ] Dependency：`r`n"
        . "[ ] Before Evidence：`r`n[ ] Import Result：`r`n[ ] After Evidence：`r`n"
        . "[ ] Rollback / Recovery consideration：`r`n`r`n"
        . "WARNING: STMS Import 必须由人员在 SAP 中手工执行并确认。"
    CopyToClipboard(text, "SAP Transport Checklist 已复制；不会执行 Import。")
}

CopySapCertificateChecklist(*) {
    text := "SAP STRUST Certificate Checklist`r`n"
        . "================================`r`n"
        . "[ ] Target System / Client`r`n[ ] Certificate purpose and expiry`r`n"
        . "[ ] Approval and maintenance window`r`n[ ] Current certificate evidence`r`n"
        . "[ ] Backup / recovery plan`r`n[ ] Post-change verification`r`n`r`n"
        . "WARNING: STRUST 变更必须人工执行。"
    CopyToClipboard(text, "SAP STRUST Checklist 已复制。")
}
