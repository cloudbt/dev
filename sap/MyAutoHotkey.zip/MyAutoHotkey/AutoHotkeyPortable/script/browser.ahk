^!+s::OpenSharePointInvoiceFolder()
^!+c::OpenClaudeUsage()
^!+u::OpenChatGptUsage()

OpenSharePointInvoiceFolder(*) {
    OpenBrowserUrls(EDGE_PATH, "Microsoft Edge", [SHAREPOINT_INVOICE_URL])
}

OpenClaudeUsage(*) {
    OpenBrowserUrls(CHROME_PATH, "Google Chrome", [CLAUDE_USAGE_URL], CLAUDE_CHROME_PROFILE)
}

OpenChatGptUsage(*) {
    OpenBrowserUrls(
        CHROME_PATH,
        "Google Chrome",
        [CODEX_USAGE_URL, CHATGPT_URL],
        CHATGPT_CHROME_PROFILE
    )
}
