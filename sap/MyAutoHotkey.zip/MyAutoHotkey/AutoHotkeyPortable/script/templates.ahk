CopyInitialReplyTemplate(*) {
    text := "お世話になっております。`r`n`r`n"
        . "ご連絡ありがとうございます。`r`n"
        . "本件、内容を確認のうえ調査を開始いたします。`r`n`r`n"
        . "確認が取れ次第、改めてご連絡いたします。`r`n"
        . "よろしくお願いいたします。"
    CopyToClipboard(text, "客户初回回复模板已复制。")
}

CopyNeedMoreInformationTemplate(*) {
    text := "お世話になっております。`r`n`r`n"
        . "調査のため、以下の情報をご共有いただけますでしょうか。`r`n`r`n"
        . "・発生日時：`r`n"
        . "・対象環境：`r`n"
        . "・対象ユーザー / 対象ジョブ / 対象処理：`r`n"
        . "・エラーメッセージ全文：`r`n"
        . "・再現手順：`r`n"
        . "・影響範囲：`r`n`r`n"
        . "よろしくお願いいたします。"
    CopyToClipboard(text, "追加信息请求模板已复制。")
}

CopyCompletionTemplate(*) {
    text := "お世話になっております。`r`n`r`n"
        . "作業が完了しましたので、ご報告いたします。`r`n`r`n"
        . "【対象】`r`n`r`n"
        . "【実施内容】`r`n`r`n"
        . "【結果】`r`n`r`n"
        . "よろしくお願いいたします。"
    CopyToClipboard(text, "作业完成模板已复制。")
}

CopyTeamsInternalTemplate(*) {
    text := "【Incident】`r`n"
        . "【対象】`r`n"
        . "【内容】`r`n"
        . "【こちらで確認済みの内容】`r`n"
        . "【確認いただきたい点】`r`n"
        . "【希望期限】`r`n"
    CopyToClipboard(text, "Teams 内部确认模板已复制；请确认后手动发送。")
}
