CopyIncidentInitialAssessment(*) {
    text := "Incident Initial Assessment Checklist`r`n"
        . "====================================`r`n"
        . "System：SAP / JP1 / AWS / Windows / DataSpider / HULFT / SVF`r`n"
        . "Environment：DEV / QAS / PRD`r`n"
        . "Type：作業 / 障害 / 調査 / 問い合わせ / 監視`r`n"
        . "Production Impact：`r`nApproval Required：`r`nDue Date：`r`nNext Action：`r`n"
    CopyToClipboard(text, "Incident 初期评估 Checklist 已复制。")
}

CopyIncidentCloseCandidate(*) {
    text := "Incident Close Candidate Checklist`r`n"
        . "=================================`r`n"
        . "[ ] Evidence saved`r`n"
        . "[ ] Task List updated`r`n"
        . "[ ] Incident History updated`r`n"
        . "[ ] Customer informed`r`n"
        . "[ ] No remaining action`r`n"
    CopyToClipboard(text, "Incident Close Candidate Checklist 已复制。")
}

CopyIncidentWaitingChecklist(*) {
    text := "Incident Waiting Checklist`r`n"
        . "===========================`r`n"
        . "Waiting for：`r`nRequest date：`r`nFollow-up date：`r`n"
        . "Blocker：`r`nNext Action：`r`n"
    CopyToClipboard(text, "Incident Waiting Checklist 已复制。")
}
