#Requires AutoHotkey v2.0
#SingleInstance Force

#Include config.ahk
#Include helpers.ahk
#Include keyboard.ahk
#Include launcher.ahk
#Include browser.ahk
#Include templates.ahk
#Include automation.ahk
#Include sap.ahk
#Include jp1.ahk
#Include windows.ahk
#Include incident.ahk

InitializeToolkit()

InitializeToolkit() {
    A_IconTip := "Operation Toolkit"
    A_IconHidden := !TRAY_MENU_ENABLED
    if TRAY_MENU_ENABLED
        BuildTrayMenu()
    WriteActionLog("Toolkit started")
    if TRAY_MENU_ENABLED
        TrayTip("Operation Toolkit 已启动。", "AutoHotkey v2 Portable", 1)
}

BuildTrayMenu() {
    openMenu := Menu()
    openMenu.Add("Personal Task List", OpenPersonalTaskList)
    openMenu.Add("Incident List", OpenIncidentList)
    openMenu.Add("Evidence", OpenEvidenceRoot)
    openMenu.Add("Runbook", OpenRunbook)
    openMenu.Add("Working Folder", OpenWorkingFolder)
    openMenu.Add("SAP Logon", OpenSapLogon)

    webMenu := Menu()
    webMenu.Add("SharePoint Invoice (Edge)", OpenSharePointInvoiceFolder)
    webMenu.Add("Claude Usage (Chrome Profile 3)", OpenClaudeUsage)
    webMenu.Add("ChatGPT Usage (Chrome Profile 5)", OpenChatGptUsage)

    templatesMenu := Menu()
    templatesMenu.Add("Initial Reply", CopyInitialReplyTemplate)
    templatesMenu.Add("Need More Information", CopyNeedMoreInformationTemplate)
    templatesMenu.Add("Completed", CopyCompletionTemplate)
    templatesMenu.Add("Teams Internal", CopyTeamsInternalTemplate)

    automationMenu := Menu()
    automationMenu.Add("Create Evidence Folder", CreateEvidenceFolder)
    automationMenu.Add("Create Work Memo", CreateWorkMemo)
    automationMenu.Add("Create Investigation Memo", CreateInvestigationMemo)
    automationMenu.Add("Create Daily Memo", CreateDailyMemo)
    automationMenu.Add("Start File Watcher", StartFilesWatcher)

    sapMenu := Menu()
    sapMenu.Add("PROD Safety Checklist", CopySapProdSafetyChecklist)
    sapMenu.Add("Job / Dump Checklist", CopySapJobDumpChecklist)
    sapMenu.Add("Transport Checklist", CopySapTransportChecklist)
    sapMenu.Add("STRUST Checklist", CopySapCertificateChecklist)

    jp1Menu := Menu()
    jp1Menu.Add("Pre-check", CopyJp1Precheck)
    jp1Menu.Add("Abnormal End", CopyJp1AbnormalEndChecklist)
    jp1Menu.Add("Schedule Change", CopyJp1ScheduleChangeChecklist)

    windowsMenu := Menu()
    windowsMenu.Add("Event Viewer", OpenEventViewer)
    windowsMenu.Add("Services", OpenServicesConsole)
    windowsMenu.Add("Computer Management", OpenComputerManagement)
    windowsMenu.Add("Investigation Checklist", CopyWindowsInvestigationChecklist)

    incidentMenu := Menu()
    incidentMenu.Add("Initial Assessment", CopyIncidentInitialAssessment)
    incidentMenu.Add("Waiting", CopyIncidentWaitingChecklist)
    incidentMenu.Add("Close Candidate", CopyIncidentCloseCandidate)

    systemMenu := Menu()
    systemMenu.Add("Open Config", OpenConfigFile)
    systemMenu.Add("Reload", ReloadToolkit)
    systemMenu.Add("Exit", ExitToolkit)

    A_TrayMenu.Delete()
    A_TrayMenu.Add("Open", openMenu)
    A_TrayMenu.Add("Web", webMenu)
    A_TrayMenu.Add("Templates", templatesMenu)
    A_TrayMenu.Add("Automation", automationMenu)
    A_TrayMenu.Add("SAP", sapMenu)
    A_TrayMenu.Add("JP1", jp1Menu)
    A_TrayMenu.Add("Windows", windowsMenu)
    A_TrayMenu.Add("Incident", incidentMenu)
    A_TrayMenu.Add("System", systemMenu)
    A_TrayMenu.Default := "Open"
}

OpenConfigFile(*) {
    OpenInNotepad(SCRIPT_ROOT "\config.ahk")
}

ReloadToolkit(*) {
    Reload()
}

ExitToolkit(*) {
    ExitApp()
}
