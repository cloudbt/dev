# MyAutoHotkey

## 1. 项目介绍

这是一个面向 Windows 11 的 AutoHotkey v2 Portable SAP / Non-SAP 运维辅助工具箱，重点支持 SAP Basis、JP1、AWS / Windows Server、Incident、Personal Task、Evidence、Runbook、邮件与 Teams 模板等日常工作。

项目不需要安装 AutoHotkey，直接使用仓库内的 `AutoHotkeyPortable\AutoHotkey64.exe`。它的定位是“运维辅助工具”，不会充当无人值守的生产操作机器人。

## 2. 环境

- Windows 11 64-bit
- AutoHotkey v2（当前 Portable 文件为 v2.0.26）
- Portable mode，统一使用 `AutoHotkey64.exe`
- 不依赖第三方 AutoHotkey Library，不要求管理员权限

## 3. 目录结构

```text
MyAutoHotkey\
├─ README.md
├─ .gitignore
└─ AutoHotkeyPortable\
   ├─ AutoHotkey64.exe
   ├─ AutoHotkey32.exe
   ├─ AutoHotkey.chm
   ├─ WindowSpy.ahk
   ├─ Install.cmd
   ├─ license.txt
   ├─ UX\                         # AutoHotkey 官方 UX 文件
   ├─ start.cmd
   ├─ script\
   │  ├─ main.ahk
   │  ├─ config.ahk
   │  ├─ helpers.ahk
   │  ├─ keyboard.ahk
   │  ├─ launcher.ahk
   │  ├─ browser.ahk
   │  ├─ templates.ahk
   │  ├─ automation.ahk
   │  ├─ sap.ahk
   │  ├─ jp1.ahk
   │  ├─ windows.ahk
   │  └─ incident.ahk
   ├─ template\
   │  ├─ WorkMemo.txt
   │  ├─ InvestigationMemo.txt
   │  └─ README.txt
   └─ logs\
      └─ .gitkeep
```

## 4. 第一次使用

1. Clone repository。
2. 编辑 `AutoHotkeyPortable\script\config.ahk`，换成自己的安全工作路径。
3. 双击 `AutoHotkeyPortable\start.cmd`。
4. 在 Windows 通知区域找到 `Operation Toolkit` 托盘图标。

`start.cmd` 使用相对路径启动仓库内的 64-bit AutoHotkey，因此不依赖系统安装或 `PATH`。

## 5. config.ahk 配置方法

| 配置项 | 用途 |
|---|---|
| `APP_ROOT` | Portable 根目录，由 `A_ScriptDir` 自动计算 |
| `SCRIPT_ROOT` | 模块脚本目录 |
| `TEMPLATE_ROOT` | Work Memo / Investigation Memo 模板目录 |
| `LOG_ROOT` | 仅记录本地功能动作的日志目录 |
| `TRAY_MENU_ENABLED` | `true` 显示 Tray Menu；`false` 隐藏托盘图标和菜单 |
| `WORK_ROOT` | 运维工作资料的示例根目录 |
| `INCIDENT_LIST` | Incident List 文件路径 |
| `PERSONAL_TASK_LIST` | Personal Task List 文件路径 |
| `RUNBOOK_ROOT` | Runbook 目录 |
| `EVIDENCE_ROOT` | Evidence 根目录 |
| `WORKING_ROOT` | Memo 等工作文件目录 |
| `PERSONAL_MEMO` | `Ctrl + Alt + N` 打开的个人 Memo 文件路径 |
| `SAP_LOGON` | `saplogon.exe` 完整路径 |
| `SAP_LOGON_EXE` | 用于识别已运行 SAP Logon 窗口的进程名 |
| `EDGE_PATH` | Microsoft Edge 可执行文件路径 |
| `CHROME_PATH` | Google Chrome 可执行文件路径 |
| `SHAREPOINT_INVOICE_URL` | SharePoint 请求书目录 URL |
| `CLAUDE_USAGE_URL` / `CLAUDE_CHROME_PROFILE` | Claude Usage URL 与 Chrome Profile |
| `CODEX_USAGE_URL` / `CHATGPT_URL` | ChatGPT Codex Usage 与 ChatGPT 首页 URL |
| `CHATGPT_CHROME_PROFILE` | ChatGPT 链接使用的 Chrome Profile |
| `WATCH_FILES_ROOT` | `Watch-FilesAndRunScripts.ps1` 的工作目录 |
| `WATCH_FILES_SCRIPT` | 要直接执行的 PowerShell 脚本路径 |

工作路径默认值为 `C:\Work\Operation` 下的安全示例，不包含客户数据。Web URL 不含账号、密码或认证 Token，登录状态由对应浏览器 Profile 管理。路径不存在不会影响工具启动；调用相应功能时会友好提示或改用默认浏览器。

## 6. 快捷键一览

| 快捷键 | 功能 | 文件 |
|---|---|---|
| `Ctrl + Alt + N` | 创建或打开个人 `memo.txt` | `keyboard.ahk` |
| `Ctrl + Alt + Shift + R` | Reload 工具箱 | `keyboard.ahk` |
| `Ctrl + Alt + C` | 复制当前时间 | `keyboard.ahk` |
| `Ctrl + Alt + T` | 打开 Personal Task List | `launcher.ahk` |
| `Ctrl + Alt + I` | 打开 Incident List | `launcher.ahk` |
| `Ctrl + Alt + R` | 打开 Runbook | `launcher.ahk` |
| `Ctrl + Alt + E` | 打开 Evidence 根目录 | `launcher.ahk` |
| `Ctrl + Alt + S` | 打开或激活 SAP Logon | `launcher.ahk` |
| `Ctrl + Alt + W` | 打开 Working Folder | `launcher.ahk` |
| `Ctrl + Alt + Shift + S` | 用 Edge 打开 SharePoint 请求书目录 | `browser.ahk` |
| `Ctrl + Alt + Shift + C` | 用 Chrome Profile 3 打开 Claude Usage | `browser.ahk` |
| `Ctrl + Alt + Shift + U` | 用 Chrome Profile 5 打开 Codex Usage 与 ChatGPT | `browser.ahk` |
| `Ctrl + Alt + Shift + W` | 直接启动 `Watch-FilesAndRunScripts.ps1` | `launcher.ahk` |

快捷键全部使用低风险组合，没有键盘重映射，也没有自动确认或提交操作。

## 7. Hotstring

输入缩写后键入结束字符（例如空格或 Enter）：

| 缩写 | 展开内容 |
|---|---|
| `ots` | `お疲れ様です。` |
| `yor` | `よろしくお願いいたします。` |
| `ose` | `お世話になっております。` |

## 8. Tray Menu 使用方法

托盘菜单按用途分组：

在 `config.ahk` 中设置 `TRAY_MENU_ENABLED := false` 可关闭并隐藏整个 Tray Menu；设回 `true` 后重启脚本即可恢复。关闭 Tray Menu 不影响快捷键和 Hotstring，仍可使用 `Ctrl + Alt + Shift + R` Reload。

- **Open**：Personal Task、Incident List、Evidence、Runbook、Working Folder、SAP Logon
- **Web**：SharePoint Invoice（Edge）、Claude Usage（Chrome Profile 3）、ChatGPT Usage（Chrome Profile 5）
- **Templates**：客户初回回复、追加信息请求、作业完成、Teams 内部确认
- **Automation**：Evidence Folder、Work Memo、Investigation Memo、Daily Memo、Start File Watcher
- **SAP**：PROD、Job / Dump、Transport、STRUST Checklist
- **JP1**：作业前、异常结束、Schedule Change Checklist
- **Windows**：Event Viewer、Services、Computer Management、调查 Checklist
- **Incident**：Initial Assessment、Waiting、Close Candidate
- **System**：打开配置、Reload、Exit

所有沟通模板和 Checklist 仅复制到剪贴板，请检查后手动粘贴、发送或执行。

`Automation > Start File Watcher` 会将 `WATCH_FILES_ROOT` 设为工作目录，并直接执行：

```powershell
powershell.exe -ExecutionPolicy Bypass -File ".\Watch-FilesAndRunScripts.ps1"
```

该入口不会调用 `Watch-FilesAndRunScripts.bat`。

## 9. Incident 工作流

```text
Incident
   ↓
Personal Task
   ↓
Runbook
   ↓
Evidence
   ↓
Work Memo
   ↓
Status Update
   ↓
Reply
```

建议先做 Initial Assessment，再创建 Evidence 和 Work Memo；Waiting 和 Close Candidate Checklist 用于避免遗漏跟进与关单事项。

## 10. SAP 使用例

SAP Dump 调查：

1. 用 `Automation > Create Evidence Folder` 创建证据目录。
2. 创建 Work Memo。
3. 用 `Open > SAP Logon` 打开 SAP。
4. 复制 `SAP > Job / Dump Checklist`。
5. 人工检查 ST22、SM37、SM21、SM50 / SM66、SM13。
6. 保存 Evidence，更新 Incident，使用回复模板。

PROD / F56 Checklist 会明确警告必须人工确认。Transport 和 STRUST 功能只生成 Checklist。

## 11. JP1 使用例

1. 作业前复制 `JP1 > Pre-check`，确认 Jobnet、前后续、Calendar、Schedule 和恢复方案。
2. 异常结束时使用 `JP1 > Abnormal End` 整理 Return Code、Log、影响与 Rerun 可能性。
3. Schedule 变更时使用 `JP1 > Schedule Change` 保存前后 Evidence。

工具不会修改 JP1 Job、定义或 Schedule，也不会执行 Rerun。

## 12. Windows Server 使用例

从 `Windows` 菜单打开 Event Viewer、Services 或 Computer Management 做只读调查，并复制 Investigation Checklist 记录 Service、Event Log、Disk、CPU、Memory、Certificate 和日志更新时间。权限不足时会提示，不会请求提权。

## 13. Template 使用例

选择 `Templates > Initial Reply` 后，日语回复会进入剪贴板。切换到邮件或 Teams，手动按 `Ctrl + V`，检查 Incident、对象、时间和措辞后再发送。其他模板采用相同的安全流程；工具不会自动点击 Send。

## 14. Evidence Folder 命名规则

```text
EVIDENCE_ROOT\yyyy\yyyyMM\INCxxxxx_System_Description
```

例：`02_Evidence\2026\202609\INC51031_SAP_ST22_Dump`。输入中的 Windows 非法文件名字符会替换为 `_`；创建完成后自动打开目录并复制路径。

## 15. 安全设计

本工具不会自动执行生产系统变更。PROD、F56、本番 JP1 相关功能仅显示 Checklist、警告，或辅助打开工具、创建 Evidence 与 Memo。

以下操作必须人工执行：

- SAP Transport Import
- SAP User modification（SU01）
- SAP Parameter modification（RZ10 / RZ11）
- SAP Client operation
- SAP Certificate modification（STRUST）
- JP1 definition / Schedule modification
- Service restart、Server restart
- AWS configuration modification
- 日志删除、Shutdown、Reboot 等破坏性动作

日志只记录 `Toolkit started`、`Evidence folder created` 等功能动作，不记录 Incident 详情、客户数据、密码或 Token；`logs\*.log` 默认不提交。

## 16. 开发说明

| 文件 | 职责 |
|---|---|
| `main.ahk` | v2 入口、初始化、Tray Menu 和全局入口 |
| `config.ahk` | 环境路径和程序路径配置 |
| `helpers.ahk` | 安全打开、剪贴板、目录、文件名、时间、模板、日志等公共函数 |
| `keyboard.ahk` | 通用 Hotstring、个人 Memo、Reload、时间复制 |
| `launcher.ahk` | Personal Task、Incident、Runbook、Evidence、SAP 等启动入口 |
| `browser.ahk` | Edge / Chrome 指定 Profile 的 Web 链接入口 |
| `templates.ahk` | 日语客户与 Teams 文本模板 |
| `automation.ahk` | Evidence、Work Memo、Investigation Memo、Daily Memo 创建 |
| `sap.ahk` | SAP 安全与调查 Checklist |
| `jp1.ahk` | JP1 作业前、异常结束、Schedule Checklist |
| `windows.ahk` | Windows 管理工具入口与调查 Checklist |
| `incident.ahk` | Incident 初期评估、Waiting、Close Candidate Checklist |

所有业务模块均由 `main.ahk` 使用 `#Include` 加载，语法统一为 AutoHotkey v2。

## 17. 新增快捷键方法

先确认 README 中没有冲突，再在适当模块添加 AutoHotkey v2 Hotkey，例如：

```ahk
^!d::CreateDailyMemo()  ; Ctrl + Alt + D
```

函数应放在职责对应的模块，路径应引用 `config.ahk`，重复操作应使用 `helpers.ahk`。

## 18. Troubleshooting

### 路径不存在

编辑 `script\config.ahk`。工具启动不要求这些路径存在，仅在使用功能时检查。

### AHK script error

确认脚本使用 v2 语法，并从 `start.cmd` 启动。错误窗口通常会显示文件和行号；修改后从 Tray Menu 执行 Reload。

### 快捷键冲突

查看“快捷键一览”，再检查其他常驻软件。调整模块中的 Hotkey 并同步更新 README。

### 脚本没有启动

检查通知区域是否已有 `Operation Toolkit`。如没有，直接双击 `start.cmd` 并查看错误提示。

### AutoHotkey64.exe 找不到

确认 `start.cmd` 与 `AutoHotkey64.exe` 位于同一个 `AutoHotkeyPortable` 目录，且文件没有被安全软件隔离。

### 公司 PC 权限问题

部分 MMC 工具或 SAP 路径可能受公司策略限制。工具不会自动提升权限；请遵守公司流程或联系管理员。

## 19. Git 更新方法

更新前先检查自己的未提交内容：

```powershell
git pull
git status
git add README.md AutoHotkeyPortable/script
git commit -m "describe your change"
git push
```

不要提交 `logs\*.log`、个人 Memo、客户资料、账号、密码、Token、IP 或真实 Incident 内容。提交前建议运行 `git diff --check` 并复核变更。
