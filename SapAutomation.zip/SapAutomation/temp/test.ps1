﻿$regexSubject = '^(?:Subject|件名)\s*[:：]?\s*(.+)$'
$content = @"
Subject: Test
件名：テストメール
"@

$m = [regex]::Match($content, $regexSubject, [System.Text.RegularExpressions.RegexOptions]::Multiline)
if ($m.Success) {
    Write-Host "Matched: $($m.Groups[1].Value)"
} else {
    Write-Host "No match"
}
