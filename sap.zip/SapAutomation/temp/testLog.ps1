# $logDir = "../logs"
# if (-not (Test-Path $logDir)) {
#     New-Item -ItemType Directory -Path $logDir | Out-Null
# }
# $logFile = Join-Path $logDir ("script_log_{0}.txt" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
# function Write-Log {
#     param (
#         [string]$Message,
#         [ConsoleColor]$Color = [ConsoleColor]::White
#     )
#     Write-Host $Message -ForegroundColor $Color
#     Add-Content -Path $logFile -Value ("[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Message)
# }

# Write-Log "test"

    $workbookName = "Book1.xlsx"
    $sheetName = "Sheet1"
    $excel = [Runtime.InteropServices.Marshal]::GetActiveObject("Excel.Application")
    $workbooks = $excel.Workbooks
    $workbook = $null
    foreach ($wb in $workbooks) {
        if ($wb.Name -eq $workbookName) { $workbook = $wb }
    }
    if (-not $workbook) { throw "Workbook $workbookName not found" }
    $worksheet = $workbook.Sheets.Item($sheetName)

    $worksheet.Cells.Item(1, 2).Value2 = "test"