﻿$counterFile = "./rowCounter.txt"

if (Test-Path $counterFile) {
    $persistentRowCounter = [int](Get-Content $counterFile)
} else {
    $persistentRowCounter = 2494
}

$persistentRowCounter = 3000

$persistentRowCounter | Set-Content $counterFile
$persistentRowCounter | Set-Content $counterFile

