﻿# 1. Set the parent directory path to read
$parentFolderPath = "../output"

# 2. Check
if (-not (Test-Path -Path $parentFolderPath -PathType Container)) {
    Write-Host "The specified directory does not exist: $parentFolderPath" -ForegroundColor Red
    exit
}

# 3. Get all subfolders under the directory (only folders, no files)
$allFolders = Get-ChildItem -Path $parentFolderPath -Directory

# 4. Check if there are any subfolders
if ($allFolders.Count -eq 0) {
    Write-Host "There are no subfolders under the specified directory: $parentFolderPath" -ForegroundColor Yellow
    exit
}

# 5. Display the list of folders and choose
Write-Host "Below are all subfolders under the directory '$parentFolderPath', please select the ones you need (multiple selection allowed):" -ForegroundColor Cyan

# Use Out-GridView to show folder names and allow user multi-selection
# -Title: The title of the popup window
# -PassThru: Allows selecting multiple items and returns the selected ones
# -Property Name: Only show folder Name (you can also show FullName)
$selectedFolders = $allFolders | 
    Select-Object Name, FullName | 
    Out-GridView -Title "Please select one or more subfolders (multiple selection allowed, click OK after selecting)" -PassThru

# 6. Check if the user has selected any folders
if (-not $selectedFolders) {
    Write-Host "You did not select any folders. The operation has been canceled." -ForegroundColor Yellow
    exit
}

# 7. Extract the selected folder names or full paths into an array 
# ---- Option 1: If you only need the "Name" of the folders (e.g., "Folder1")
$selectedFolderNames = $selectedFolders | ForEach-Object { $_.Name }
# ---- Option 2: If you need the "Full Path" of the folders (e.g., "C:\Your\Folder\Path\Folder1")
$selectedFolderFullPaths = $selectedFolders | ForEach-Object { $_.FullName }

# 8. Output the selected result (optional, for debugging)
Write-Host "`nThe folders you selected are as follows:" -ForegroundColor Green

# Output the selected names
$selectedFolderNames | ForEach-Object { Write-Host "  $_" }

# Alternatively, output the selected full paths (recommended for further operations)
# $selectedFolderFullPaths | ForEach-Object { Write-Host "  $_" }

# 9. The final array you want to use (recommend using full paths as they are more practical)
#      You can choose either $selectedFolderNames or $selectedFolderFullPaths
$selectedFolderArray = $selectedFolderFullPaths  # Or use $selectedFolderNames if you prefer names

# 10. Print the final array content (for debugging)
Write-Host "`nThe final selected folder array (variable name: `$selectedFolderArray), total items: $($selectedFolderArray.Count):" -ForegroundColor Cyan
$selectedFolderArray | ForEach-Object { Write-Host "  - $_" }

$jsonPath = $selectedFolderFullPaths + "\" + $selectedFolderNames + ".json"

Write-Host $jsonPath