﻿function Get-ClientNumberFromEmail {
    param (
        [string]$Subject,
        [string]$Body
    )
    
    $clientNo = $null
    
    if ($Subject -match 'Client(\d+)') {
        $clientNo = $Matches[1]
        Write-Verbose "Found Client No in subject: $clientNo" -Verbose
        return $clientNo
    }
    elseif ($Body -match 'Client #\s*[：:](\d+)') {
        $clientNo = $Matches[1]
        Write-Verbose "Found Client No in body: $clientNo" -Verbose
        return $clientNo
    }
    else {
        Write-Verbose "No found ClientNo in subject or body" -Verbose
        return $null
    }
}

# 模拟 Subject 和 Body
$Subject = '[Asi-Oce Non-SAP]F56_Req_User ID'
$Body = @"
Dear Asi-Oce Infrastructure team,

I request to Infra-team as follows:

【User ID Request】

 
Client #        ：501
Requester     ：DIID Fathur*Approve by DIID Rudi

Request From Link：DEV spider
"@

$clientNo = Get-ClientNumberFromEmail -Subject $Subject -Body $Body -Verbose
Write-Host "✅ 提取结果: $clientNo"

